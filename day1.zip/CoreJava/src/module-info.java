/**
 * 
 */
/**
 * 
 */
module CoreJava {
}